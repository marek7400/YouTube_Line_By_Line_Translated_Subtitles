(() => {
    // Sprawdź, czy panel już istnieje, aby go tylko pokazać/ukryć
    const existingPanel = document.getElementById('yt-custom-subs-settings-panel');
    if (existingPanel) {
        existingPanel.style.display = existingPanel.style.display === 'none' ? 'flex' : 'none';
        return;
    }

    // --- Programistyczne budowanie DOM ---

    const panel = document.createElement('div');
    panel.id = 'yt-custom-subs-settings-panel';
    panel.style.cssText = `
        position: fixed; width: 350px; background: #181818; color: white;
        border-radius: 12px; z-index: 10002; font-family: sans-serif; display: flex; flex-direction: column;
        border: 1px solid #3e3e3e; box-shadow: 0 4px 8px rgba(0,0,0,0.5); font-size: 14px;
        transform: translate(-50%, -50%);
    `;

    const style = document.createElement('style');
    style.textContent = `
        #yt-custom-subs-settings-panel button.toggle-btn {
            width: 100%;
            padding: 8px;
            background: #3ea6ff;
            color: #0d0d0d;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            margin-bottom: 10px;
            transition: background-color 0.2s;
        }
        #yt-custom-subs-settings-panel button.toggle-btn:hover { background: #66baff; }
        #yt-custom-subs-settings-panel .control-group { display: flex; justify-content: space-between; align-items: center; }
        #yt-custom-subs-settings-panel .slider-group { display: flex; flex-direction: column; gap: 5px; }
        #yt-custom-subs-settings-panel .slider-wrapper { display: flex; align-items: center; gap: 10px; }
        #yt-custom-subs-settings-panel .slider-wrapper input[type=range] { flex-grow: 1; }
        #yt-custom-subs-settings-panel input[type=number] { width: 60px; }
        #yt-custom-subs-settings-panel input { background: #333; color: #fff; border: 1px solid #555; border-radius: 4px; padding: 2px 5px; }
    `;
    document.head.appendChild(style);

    // Nagłówek
    const header = document.createElement('div');
    header.id = 'yt-custom-subs-settings-header';
    header.style.cssText = `padding: 10px 15px; background: #282828; border-bottom: 1px solid #3e3e3e; cursor: move; border-top-left-radius: 12px; border-top-right-radius: 12px;`;
    header.textContent = 'Subtitle Settings';

    const closeBtn = document.createElement('button');
    closeBtn.style.cssText = 'position: absolute; top: 5px; right: 10px; background:none; border:none; color:white; font-size:24px; cursor:pointer; width: auto; padding: 0; margin: 0;';
    closeBtn.textContent = '×';
    closeBtn.onclick = () => panel.style.display = 'none';
    header.appendChild(closeBtn);
    
    // Kontener na zawartość
    const contentContainer = document.createElement('div');
    contentContainer.style.cssText = 'padding: 15px; overflow-y: auto; display: flex; flex-direction: column; gap: 15px;';

    // Przycisk ON/OFF
    const toggleBtn = document.createElement('button');
    toggleBtn.id = 'yt-custom-subs-toggle-btn';
    toggleBtn.className = 'toggle-btn';
    contentContainer.appendChild(toggleBtn);

    // Przełącznik trybu
    const modeSelector = document.createElement('div');
    modeSelector.style.cssText = 'text-align: center; padding-bottom: 10px; border-bottom: 1px solid #3e3e3e; margin-bottom: 5px;';
    const normalLabel = document.createElement('label');
    const normalRadio = document.createElement('input');
    normalRadio.type = 'radio';
    normalRadio.name = 'viewMode';
    normalRadio.value = 'normal';
    normalRadio.checked = true;
    normalLabel.append(normalRadio, ' Normal');
    const fullscreenLabel = document.createElement('label');
    fullscreenLabel.style.marginLeft = '20px';
    const fullscreenRadio = document.createElement('input');
    fullscreenRadio.type = 'radio';
    fullscreenRadio.name = 'viewMode';
    fullscreenRadio.value = 'fullscreen';
    fullscreenLabel.append(fullscreenRadio, ' Fullscreen');
    modeSelector.append(normalLabel, fullscreenLabel);
    contentContainer.appendChild(modeSelector);
    
    // Funkcje pomocnicze do tworzenia kontrolek
    const createControl = (label, type, dataKey, props = {}) => {
        const div = document.createElement('div');
        div.className = 'control-group';
        const labelEl = document.createElement('label');
        labelEl.textContent = label;
        const inputEl = document.createElement('input');
        inputEl.type = type;
        inputEl.dataset.key = dataKey;
        Object.assign(inputEl, props);
        div.append(labelEl, inputEl);
        return div;
    };

    const createSlider = (label, dataKey, props = {}) => {
        const div = document.createElement('div');
        div.className = 'slider-group';
        const labelEl = document.createElement('label');
        labelEl.textContent = label;
        const wrapper = document.createElement('div');
        wrapper.className = 'slider-wrapper';
        const rangeEl = document.createElement('input');
        rangeEl.type = 'range';
        rangeEl.dataset.key = dataKey;
        Object.assign(rangeEl, props);
        const numberEl = document.createElement('input');
        numberEl.type = 'number';
        numberEl.dataset.key = dataKey;
        Object.assign(numberEl, props);
        rangeEl.oninput = () => numberEl.value = rangeEl.value;
        numberEl.oninput = () => rangeEl.value = rangeEl.value;
        wrapper.append(rangeEl, numberEl);
        div.append(labelEl, wrapper);
        return div;
    };
    
    // Dodawanie kontrolek
    contentContainer.appendChild(createControl('Color:', 'color', 'color'));
    contentContainer.appendChild(createControl('Font Size (px):', 'number', 'fontSize', { min: 8, max: 80 }));
    contentContainer.appendChild(createSlider('Container Width (%):', 'containerWidth', { min: 40, max: 100, step: 1 }));
    contentContainer.appendChild(createControl('BG Color:', 'color', 'bgColor'));
    contentContainer.appendChild(createSlider('BG Opacity:', 'bgOpacity', { min: 0, max: 1, step: 0.05 }));
    contentContainer.appendChild(createSlider('V-Position (px from bottom):', 'vPosition', { min: 0, max: 400 }));
    contentContainer.appendChild(createControl('Time Offset (ms):', 'number', 'timeOffset', { step: 50 }));

    panel.append(header, contentContainer);
    document.body.appendChild(panel);

    // Wyśrodkowanie
    panel.style.top = '50%';
    panel.style.left = '50%';

    // --- Logika Panelu ---
    let currentSettings = null; 

    // Logika przeciągania
    let isDragging = false, offsetX, offsetY;
    header.addEventListener('mousedown', (e) => {
        isDragging = true;
        offsetX = e.clientX - panel.offsetLeft;
        offsetY = e.clientY - panel.offsetTop;
        document.body.style.userSelect = 'none';
    });
    document.addEventListener('mouseup', () => {
        isDragging = false;
        document.body.style.userSelect = '';
    });
    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            panel.style.left = `${e.clientX - offsetX}px`;
            panel.style.top = `${e.clientY - offsetY}px`;
        }
    });
    
    // Uzupełnianie panelu danymi
    const populatePanel = (settings) => {
        currentSettings = settings;
        const mode = panel.querySelector('input[name="viewMode"]:checked').value;
        const s = settings[mode];
        if (!s) return;

        toggleBtn.textContent = s.enabled ? 'Turn Subtitles OFF' : 'Turn Subtitles ON';

        panel.querySelectorAll('input[data-key]').forEach(input => {
            const key = input.dataset.key;
            if (input.type === 'range' || (input.type === 'number' && panel.querySelector(`input[type=range][data-key="${key}"]`))) {
                panel.querySelectorAll(`input[data-key="${key}"]`).forEach(el => el.value = s[key]);
            } else {
                input.value = s[key];
            }
        });
    };
    
    // Obsługa przycisku ON/OFF
    toggleBtn.onclick = () => {
        if (!currentSettings) return;
        const currentMode = panel.querySelector('input[name="viewMode"]:checked').value;
        const newEnabledState = !currentSettings[currentMode].enabled;
        
        // Zaktualizuj tekst przycisku natychmiast
        toggleBtn.textContent = newEnabledState ? 'Turn Subtitles OFF' : 'Turn Subtitles ON';
        
        // Zaktualizuj stan w pamięci, aby kolejne kliknięcia działały poprawnie
        currentSettings.normal.enabled = newEnabledState;
        currentSettings.fullscreen.enabled = newEnabledState;

        // Wyślij zdarzenie
        window.dispatchEvent(new CustomEvent('YTCustomSubsSetSetting', { detail: { mode: 'global', key: 'enabled', value: newEnabledState } }));
    };

    // Nasłuchuj na odpowiedź z ustawieniami z content.js
    window.addEventListener('YTCustomSubsSettingsResponse', (e) => {
        populatePanel(e.detail);
    });

    // Poproś o aktualne ustawienia
    window.dispatchEvent(new CustomEvent('YTCustomSubsGetSettings'));

    // Ustaw nasłuchiwanie na zmiany w pozostałych polach
    panel.querySelectorAll('input:not([name=viewMode])').forEach(input => {
        input.addEventListener('input', () => {
            const mode = panel.querySelector('input[name="viewMode"]:checked').value;
            const key = input.dataset.key;
            if (!key) return;

            const value = input.type === 'color' ? input.value : (input.type === 'range' ? parseFloat(input.value) : parseInt(input.value, 10));
            
            // Synchronizacja slidera i pola numerycznego
            if (input.type === 'range' || (input.type === 'number' && panel.querySelector(`input[type=range][data-key="${key}"]`))) {
                panel.querySelectorAll(`input[data-key="${key}"]`).forEach(el => el.value = value);
            }
            
            // Wyślij zdarzenie
            window.dispatchEvent(new CustomEvent('YTCustomSubsSetSetting', { detail: { mode, key, value } }));
        });
    });

    // Ustaw nasłuchiwanie na zmianę trybu Normal/Fullscreen
    panel.querySelectorAll('input[name="viewMode"]').forEach(radio => {
        radio.addEventListener('change', () => {
            if (currentSettings) {
                populatePanel(currentSettings);
            }
        });
    });
})();