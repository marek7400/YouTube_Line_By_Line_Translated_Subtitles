(() => {
    // --- CZĘŚĆ 1: ZMIENNE I USTAWIENIA ---
    let activeSubData = null, customSubtitleElement = null, rendererInterval = null, playerApi = null, settings = {};
    let isHoveringControls = false;
    let initialLanguageCheckDone = false;
    let lastActiveSubDataCache = null;

    const defaultSettings = {
        normal: { enabled: true, color: '#FFFFFF', fontSize: 22, bgOpacity: 0.8, bgColor: '#000000', vPosition: 40, timeOffset: 0, containerWidth: 80 },
        fullscreen: { enabled: true, color: '#FFFFFF', fontSize: 28, bgOpacity: 0.7, bgColor: '#000000', vPosition: 60, timeOffset: 0, containerWidth: 80 }
    };

    // --- CZĘŚĆ 2: LOGIKA USTAWIEŃ ---
    function saveSettings() { try { localStorage.setItem('yt-custom-subs-settings', JSON.stringify(settings)); } catch(e) { console.error("Failed to save settings", e); }}
    function loadSettings(callback) {
        const saved = localStorage.getItem('yt-custom-subs-settings');
        settings = saved ? {
            normal: { ...defaultSettings.normal, ...JSON.parse(saved).normal },
            fullscreen: { ...defaultSettings.fullscreen, ...JSON.parse(saved).fullscreen }
        } : JSON.parse(JSON.stringify(defaultSettings));
        if (callback) callback();
    }
    function hexToRgba(hex, opacity) { let c; if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) { c = hex.substring(1).split(''); if (c.length == 3) c = [c[0], c[0], c[1], c[1], c[2], c[2]]; c = '0x' + c.join(''); return `rgba(${[(c >> 16) & 255, (c >> 8) & 255, c & 255].join(',')},${opacity})`; } return `rgba(0,0,0,${opacity})`; }
    function applyStyles() { if (!customSubtitleElement) return; const mode = document.fullscreenElement ? 'fullscreen' : 'normal'; const s = settings[mode]; const controlsHeight = 65; const bottomPosition = isHoveringControls ? `${controlsHeight}px` : `${s.vPosition}px`; customSubtitleElement.style.color = s.color; customSubtitleElement.style.fontSize = `${s.fontSize}px`; customSubtitleElement.style.backgroundColor = hexToRgba(s.bgColor, s.bgOpacity); customSubtitleElement.style.bottom = bottomPosition; customSubtitleElement.style.width = `${s.containerWidth}%`; }

    // --- CZĘŚĆ 3: KOMUNIKACJA ---
    window.addEventListener('YTCustomSubsGetSettings', () => { window.dispatchEvent(new CustomEvent('YTCustomSubsSettingsResponse', { detail: settings })); });
    window.addEventListener('YTCustomSubsSetSetting', (e) => {
        const { mode, key, value } = e.detail;
        if (key === 'enabled') {
            settings.normal.enabled = value;
            settings.fullscreen.enabled = value;
            if (value && lastActiveSubDataCache) {
                activeSubData = lastActiveSubDataCache;
                startRenderer();
            } else {
                stopRenderer();
            }
        } else if (settings[mode] && settings[mode][key] !== undefined) {
            settings[mode][key] = value;
            applyStyles();
        }
        saveSettings();
    });

    // --- CZĘŚĆ 4: LOGIKA NAPISÓW ---
    function processSubtitles(data) { return (data.events || []).filter(e => e.segs && e.segs.map(s => s.utf8).join('').trim() !== '').map((event, i, all) => { const start = event.tStartMs; const text = event.segs.map(s => s.utf8).join('').replace(/\\n/g, '\n').trim(); const next = all[i + 1]; let end = next ? next.tStartMs : start + (event.dDurationMs || 3000); if (end <= start) end = start + 1000; return { start, end, text }; }); }
    
    function setActiveTrack(data) {
        lastActiveSubDataCache = data; // Zawsze zapisuj ostatnie dane w pamięci podręcznej

        const mode = document.fullscreenElement ? 'fullscreen' : 'normal';
        if (settings[mode].enabled) {
            activeSubData = data;
            startRenderer();
        } else {
            stopRenderer();
        }
    }

    const originalFetch = window.fetch;
    window.fetch = function(...args) {
        const url = args[0] instanceof URL ? args[0].href : String(args[0]);
        if (url.includes('/api/timedtext')) {
            return originalFetch.apply(this, args).then(response => {
                const clone = response.clone();
                clone.json().then(jsonData => {
                    const data = processSubtitles(jsonData);
                    setActiveTrack(data);
                }).catch(e => console.error("Error processing subtitle fetch response:", e));
                return response;
            });
        }
        return originalFetch.apply(this, args);
    };

    const originalXhrOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) { if (String(url).includes('/api/timedtext')) { this._isSubtitleRequest = true; } originalXhrOpen.apply(this, [method, url, ...rest]); };
    const originalXhrSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function(...args) {
        if (this._isSubtitleRequest) {
            this.addEventListener('load', () => {
                try {
                    const jsonData = JSON.parse(this.responseText);
                    const data = processSubtitles(jsonData);
                    setActiveTrack(data);
                } catch (e) { /* ignore */ }
            });
        }
        originalXhrSend.apply(this, args);
    };

    function startRenderer() { if (rendererInterval) return; rendererInterval = setInterval(renderSubtitle, 100); }
    function stopRenderer() { if (rendererInterval) clearInterval(rendererInterval); rendererInterval = null; if (customSubtitleElement) { customSubtitleElement.style.opacity = '0'; customSubtitleElement.innerText = ''; } activeSubData = null; }
    function renderSubtitle() {
        if (!activeSubData || typeof activeSubData.find !== 'function' || !playerApi || typeof playerApi.getCurrentTime !== 'function' || !customSubtitleElement) {
            stopRenderer();
            return;
        }
        const mode = document.fullscreenElement ? 'fullscreen' : 'normal';
        if (!settings[mode]) return; // Zabezpieczenie na wypadek braku ustawień
        const offset = settings[mode].timeOffset;
        const timeMs = (playerApi.getCurrentTime() * 1000) + offset;
        const active = activeSubData.find(sub => timeMs >= sub.start && timeMs < sub.end);
        
        if (active) {
            if (customSubtitleElement.innerText !== active.text) { customSubtitleElement.innerText = active.text; }
            customSubtitleElement.style.opacity = '1';
        } else {
            customSubtitleElement.style.opacity = '0';
        }
    }

    // NOWA FUNKCJA: Resetuje stan przy zmianie filmu
    function resetStateForNewVideo() {
        console.log('[Custom Subs] Navigation detected. Resetting state.');
        stopRenderer();
        lastActiveSubDataCache = null;
        initialLanguageCheckDone = false;
        // Oznaczamy, że silnik musi być ponownie zainicjowany dla nowego odtwarzacza
        window.__CUSTOM_SUBS_INITIALIZED__ = false; 
        startObserving(); // Zaczynamy ponownie obserwować, by znaleźć nowy odtwarzacz
    }

    // PRZENIESIONA LOGIKA: Sprawdzenie języka
    function performInitialLanguageCheck() {
        if (initialLanguageCheckDone) return;
        initialLanguageCheckDone = true; // Ustawiamy na początku, aby uniknąć powtórzeń

        try {
            const playerResponse = window.ytInitialPlayerResponse || (playerApi && playerApi.getPlayerResponse ? playerApi.getPlayerResponse() : null);
            if (!playerResponse) return;

            const userLang = navigator.language.split('-')[0].toLowerCase();
            const videoLang = playerResponse?.videoDetails?.languageCode?.split('-')[0].toLowerCase();
            
            if (userLang && videoLang && userLang === videoLang) {
                console.log(`[Custom Subs] Video language (${videoLang}) matches user language (${userLang}). Disabling subs by default.`);
                settings.normal.enabled = false;
                settings.fullscreen.enabled = false;
                saveSettings(); // Zapisujemy zmianę
            }
        } catch (e) {
            console.error('[Custom Subs] Error during initial language check:', e);
        }
    }


    // --- CZĘŚĆ 5: INICJALIZACJA ---
    function initializeCustomSubtitleEngine(player) {
        if (window.__CUSTOM_SUBS_INITIALIZED__) return;
        window.__CUSTOM_SUBS_INITIALIZED__ = true;
        
        playerApi = player;
        
        loadSettings(() => {
            // ZMIANA: Sprawdzenie języka jest teraz tutaj
            performInitialLanguageCheck();

            // Reszta inicjalizacji
            if (!document.getElementById('yt-custom-subs-style')) {
              const style = document.createElement('style');
              style.id = 'yt-custom-subs-style';
              style.textContent = '.ytp-caption-window-container { display: none !important; }';
              document.head.appendChild(style);
            }

            if (!document.getElementById('yt-custom-subs-element')) {
              customSubtitleElement = document.createElement('div');
              customSubtitleElement.id = 'yt-custom-subs-element';
              customSubtitleElement.style.cssText = `position: absolute; left: 50%; transform: translateX(-50%); padding: 3px 10px; border-radius: 4px; font-family: "YouTube Noto", Roboto, "Arial Unicode Ms", Arial, Helvetica, Verdana, "PT Sans Caption", sans-serif; text-align: center; z-index: 100; pointer-events: none; transition: opacity 0.2s, bottom 0.3s ease-out, font-size 0.2s, width 0.2s; opacity: 0; text-shadow: 1px 1px 2px #000, -1px -1px 2px #000, 1px -1px 2px #000, -1px 1px 2px #000; white-space: pre-line; box-sizing: border-box;`;
              player.appendChild(customSubtitleElement);
            } else {
              customSubtitleElement = document.getElementById('yt-custom-subs-element');
            }
            
            const controlsContainer = player.querySelector('.ytp-chrome-bottom');
            if (controlsContainer) {
                controlsContainer.addEventListener('mouseenter', () => { isHoveringControls = true; applyStyles(); });
                controlsContainer.addEventListener('mouseleave', () => { isHoveringControls = false; applyStyles(); });
            }
            
            applyStyles();
            document.addEventListener('fullscreenchange', applyStyles);

            console.log('[Custom Subs] Subtitle engine initialized.');
        });
    }

    function startObserving() { 
        const observer = new MutationObserver((mutations, obs) => { 
            const player = document.getElementById('movie_player'); 
            if (player && typeof player.addEventListener === 'function') { 
                initializeCustomSubtitleEngine(player); 
                obs.disconnect(); 
            } 
        }); 
        observer.observe(document.body, { childList: true, subtree: true }); 
    }
    
    // ZMIANA: Dodajemy nasłuch na nawigację
    window.addEventListener('yt-navigate-finish', resetStateForNewVideo);

    if (document.readyState === 'loading') { 
        document.addEventListener('DOMContentLoaded', startObserving); 
    } else { 
        startObserving(); 
    }
})();