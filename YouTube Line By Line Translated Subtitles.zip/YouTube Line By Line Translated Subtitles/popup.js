document.addEventListener('DOMContentLoaded', function() {
    const subtitlesToggle = document.getElementById('subtitlesToggle');
    const fontSize = document.getElementById('fontSize');
    const fontSizeValue = document.getElementById('fontSizeValue');
    const fullscreenFontSize = document.getElementById('fullscreenFontSize');
    const fullscreenFontSizeValue = document.getElementById('fullscreenFontSizeValue');
    const fontColor = document.getElementById('fontColor');
    const fullscreenFontColor = document.getElementById('fullscreenFontColor');
    const containerOpacity = document.getElementById('containerOpacity');
    const containerOpacityValue = document.getElementById('containerOpacityValue');
    const fullscreenContainerOpacity = document.getElementById('fullscreenContainerOpacity');
    const fullscreenContainerOpacityValue = document.getElementById('fullscreenContainerOpacityValue');
    const containerColor = document.getElementById('containerColor');
    const fullscreenContainerColor = document.getElementById('fullscreenContainerColor');
    const subtitleTimeShift = document.getElementById('subtitleTimeShift');
    const sourceManual = document.getElementById('sourceManual');
    const sourceAuto = document.getElementById('sourceAuto');
    const languageSelect = document.getElementById('languageSelect');
    const subtitleWidth = document.getElementById('subtitleWidth');
    const subtitleWidthValue = document.getElementById('subtitleWidthValue');

    let settings = {};
    let manualLangs = [];
    let autoLangs = [];

    // Load settings from storage
    chrome.storage.sync.get(null, function(items) {
        settings = {
            subtitlesEnabled: items.subtitlesEnabled !== false,
            fontSize: items.fontSize || 32,
            fullscreenFontSize: items.fullscreenFontSize || 38,
            fontColor: items.fontColor || '#FFFFFF',
            fullscreenFontColor: items.fullscreenFontColor || '#FFFFFF',
            containerOpacity: items.containerOpacity !== undefined ? items.containerOpacity : 0.7,
            fullscreenContainerOpacity: items.fullscreenContainerOpacity !== undefined ? items.fullscreenContainerOpacity : 0.7,
            containerColor: items.containerColor || '#000000',
            fullscreenContainerColor: items.fullscreenContainerColor || '#000000',
            subtitleTimeShift: items.subtitleTimeShift || 100,
            subtitleSource: items.subtitleSource || 'manual',
            selectedLanguage: items.selectedLanguage || (navigator.language || navigator.userLanguage).split('-')[0],
            subtitleWidth: items.subtitleWidth || 70
        };
        updateUI();
    });

    function updateUI() {
        subtitlesToggle.textContent = settings.subtitlesEnabled ? 'ON' : 'OFF';
        fontSize.value = settings.fontSize;
        fontSizeValue.textContent = settings.fontSize;
        fullscreenFontSize.value = settings.fullscreenFontSize;
        fullscreenFontSizeValue.textContent = settings.fullscreenFontSize;
        fontColor.value = settings.fontColor;
        fullscreenFontColor.value = settings.fullscreenFontColor;
        containerOpacity.value = settings.containerOpacity;
        containerOpacityValue.textContent = settings.containerOpacity.toFixed(1);
        fullscreenContainerOpacity.value = settings.fullscreenContainerOpacity;
        fullscreenContainerOpacityValue.textContent = settings.fullscreenContainerOpacity.toFixed(1);
        containerColor.value = settings.containerColor;
        fullscreenContainerColor.value = settings.fullscreenContainerColor;
        subtitleTimeShift.value = settings.subtitleTimeShift;
        
        if (settings.subtitleSource === 'manual') {
            sourceManual.checked = true;
        } else {
            sourceAuto.checked = true;
        }
        
        subtitleWidth.value = settings.subtitleWidth;
        subtitleWidthValue.textContent = settings.subtitleWidth;
        
        updateLanguageDropdown();
    }

    // **FIXED:** Use a direct request-response pattern to get language lists.
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs[0] && tabs[0].id && tabs[0].url && tabs[0].url.includes("youtube.com/watch")) {
            chrome.tabs.sendMessage(tabs[0].id, { action: "getLanguageLists" }, function(response) {
                if (chrome.runtime.lastError) {
                    console.error("Could not get language lists:", chrome.runtime.lastError.message);
                    populateLanguageSelect([]); // Show "No languages available"
                    return;
                }
                
                if (response) {
                    console.log("Received language lists from content script:", response);
                    manualLangs = response.manual || [];
                    autoLangs = response.auto || [];
                    updateLanguageDropdown();
                } else {
                     console.error("Received an empty or invalid response for language lists.");
                     populateLanguageSelect([]);
                }
            });
        } else {
            // Not on a YouTube video page, show empty list.
            populateLanguageSelect([]);
        }
    });

    function populateLanguageSelect(languages) {
        languageSelect.innerHTML = ''; // Clear existing options
        if (languages && languages.length > 0) {
            languages.forEach(lang => {
                const option = document.createElement('option');
                option.value = lang.languageCode;
                option.textContent = lang.languageName.simpleText;
                languageSelect.appendChild(option);
            });
            if (settings.selectedLanguage) {
                // Check if the saved language is actually in the list before setting it
                const langExists = languages.some(l => l.languageCode === settings.selectedLanguage);
                if (langExists) {
                    languageSelect.value = settings.selectedLanguage;
                }
            }
        } else {
             const option = document.createElement('option');
             option.textContent = 'No languages available';
             languageSelect.appendChild(option);
        }
    }
    
    function updateLanguageDropdown() {
        if (sourceManual.checked) {
            populateLanguageSelect(manualLangs);
        } else {
            populateLanguageSelect(autoLangs);
        }
    }

    // Event listeners
    subtitlesToggle.addEventListener('click', () => { settings.subtitlesEnabled = !settings.subtitlesEnabled; updateUI(); updateSettings(false); });
    fontSize.addEventListener('input', () => { settings.fontSize = parseInt(fontSize.value); fontSizeValue.textContent = settings.fontSize; updateSettings(false); });
    fullscreenFontSize.addEventListener('input', () => { settings.fullscreenFontSize = parseInt(fullscreenFontSize.value); fullscreenFontSizeValue.textContent = settings.fullscreenFontSize; updateSettings(false); });
    fontColor.addEventListener('change', () => { settings.fontColor = fontColor.value; updateSettings(false); });
    fullscreenFontColor.addEventListener('change', () => { settings.fullscreenFontColor = fullscreenFontColor.value; updateSettings(false); });
    containerOpacity.addEventListener('input', () => { settings.containerOpacity = parseFloat(containerOpacity.value); containerOpacityValue.textContent = settings.containerOpacity.toFixed(1); updateSettings(false); });
    fullscreenContainerOpacity.addEventListener('input', () => { settings.fullscreenContainerOpacity = parseFloat(fullscreenContainerOpacity.value); fullscreenContainerOpacityValue.textContent = settings.fullscreenContainerOpacity.toFixed(1); updateSettings(false); });
    containerColor.addEventListener('change', () => { settings.containerColor = containerColor.value; updateSettings(false); });
    fullscreenContainerColor.addEventListener('change', () => { settings.fullscreenContainerColor = fullscreenContainerColor.value; updateSettings(false); });
    subtitleTimeShift.addEventListener('change', () => { settings.subtitleTimeShift = parseInt(subtitleTimeShift.value); updateSettings(false); });
    subtitleWidth.addEventListener('input', () => {
        settings.subtitleWidth = parseInt(subtitleWidth.value);
        subtitleWidthValue.textContent = settings.subtitleWidth;
        updateSettings(false);
    });

    sourceManual.addEventListener('change', updateSourceAndReload);
    sourceAuto.addEventListener('change', updateSourceAndReload);
    languageSelect.addEventListener('change', updateSourceAndReload);
    
    function updateSourceAndReload() {
        const newSource = sourceManual.checked ? 'manual' : 'auto';
        const oldSource = settings.subtitleSource;
        settings.subtitleSource = newSource;

        if (newSource === 'auto' && oldSource !== 'auto') {
            settings.selectedLanguage = (navigator.language || navigator.userLanguage).split('-')[0];
        } else {
            settings.selectedLanguage = languageSelect.value;
        }

        updateLanguageDropdown();
        updateSettings(true);
    }

    function updateSettings(reloadSubtitles = false) {
        const currentSettings = {
            subtitlesEnabled: settings.subtitlesEnabled,
            fontSize: parseInt(fontSize.value),
            fullscreenFontSize: parseInt(fullscreenFontSize.value),
            fontColor: fontColor.value,
            fullscreenFontColor: fullscreenFontColor.value,
            containerOpacity: parseFloat(containerOpacity.value),
            fullscreenContainerOpacity: parseFloat(fullscreenContainerOpacity.value),
            containerColor: containerColor.value,
            fullscreenContainerColor: fullscreenContainerColor.value,
            subtitleTimeShift: parseInt(subtitleTimeShift.value),
            subtitleSource: sourceManual.checked ? 'manual' : 'auto',
            selectedLanguage: languageSelect.value,
            subtitleWidth: parseInt(subtitleWidth.value)
        };

        chrome.storage.sync.set(currentSettings, function() {
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                if(tabs[0] && tabs[0].id && tabs[0].url && tabs[0].url.includes("youtube.com/watch")) {
                    const action = reloadSubtitles ? "reinitialize" : "updateStyle";
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: action,
                        settings: currentSettings
                    });
                }
            });
        });
    }
});