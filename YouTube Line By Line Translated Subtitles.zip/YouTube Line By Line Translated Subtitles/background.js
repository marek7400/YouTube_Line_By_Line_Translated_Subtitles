chrome.runtime.onInstalled.addListener(function() {
    chrome.storage.sync.set({subtitlesEnabled: true}, function() {
        console.log("Inicjalizacja stanu napisów");
    });
});