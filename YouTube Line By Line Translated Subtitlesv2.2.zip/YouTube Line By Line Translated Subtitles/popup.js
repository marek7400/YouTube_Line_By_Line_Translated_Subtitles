document.addEventListener('DOMContentLoaded', () => {
    const ui = document.getElementById('settings-ui');
    const errorContainer = document.getElementById('error-container');

    let currentSettings = {};

    const populatePanel = (mode) => {
        if (!currentSettings[mode]) return;
        const s = currentSettings[mode];
        document.getElementById('sub-color').value = s.color;
        document.getElementById('sub-font-size').value = s.fontSize;
        document.getElementById('sub-bg-color').value = s.bgColor;
        document.getElementById('sub-bg-opacity').value = s.bgOpacity;
        document.getElementById('sub-bg-opacity-num').value = s.bgOpacity;
        document.getElementById('sub-v-pos').value = s.vPosition;
        document.getElementById('sub-v-pos-num').value = s.vPosition;
        document.getElementById('sub-time-offset').value = s.timeOffset;
    };

    const setupListeners = () => {
        document.querySelectorAll('input').forEach(input => {
            input.addEventListener('input', (e) => {
                const mode = document.querySelector('input[name="viewMode"]:checked').value;
                const id = e.target.id.replace('-num', '');
                const value = e.target.type === 'color' ? e.target.value : (e.target.type === 'range' ? parseFloat(e.target.value) : parseInt(e.target.value));
                
                let key;
                switch (id) {
                    case 'sub-color': key = 'color'; break;
                    case 'sub-font-size': key = 'fontSize'; break;
                    case 'sub-bg-color': key = 'bgColor'; break;
                    case 'sub-bg-opacity': key = 'bgOpacity'; break;
                    case 'sub-v-pos': key = 'vPosition'; break;
                    case 'sub-time-offset': key = 'timeOffset'; break;
                }
                
                if (key) {
                    currentSettings[mode][key] = value;
                    chrome.runtime.sendMessage({ type: 'SET_SETTINGS', settings: currentSettings });
                    // Synchronize slider and number input
                    if (e.target.type === 'range') document.getElementById(`${id}-num`).value = value;
                    if (e.target.type === 'number' && document.getElementById(id).type === 'range') document.getElementById(id).value = value;
                }
            });
        });
        
        document.querySelectorAll('input[name="viewMode"]').forEach(radio => {
            radio.addEventListener('change', (e) => populatePanel(e.target.value));
        });
    };

    // Load initial settings from content script
    chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, (response) => {
        if (response && response.settings) {
            ui.style.display = 'block';
            errorContainer.style.display = 'none';
            currentSettings = response.settings;
            populatePanel('normal');
            setupListeners();
        } else {
            ui.style.display = 'none';
            errorContainer.style.display = 'block';
            console.log("Error or not a YT page:", response?.error);
        }
    });
});