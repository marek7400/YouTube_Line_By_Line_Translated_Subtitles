chrome.action.onClicked.addListener((tab) => {
  if (!tab || !tab.id || !tab.url) return;

  const url = tab.url;
  // wykrywa /watch lub /embed dla youtube.com i youtube-nocookie.com
  const isYouTubeWatchOrEmbed = /https?:\/\/(?:www\.)?youtube(?:-nocookie)?\.com\/(?:watch|embed)/i.test(url);

  // Jeśli aktualny tab to strona youtube (watch/embed) — wstrzykuj do wszystkich frame'ów
  // Jeśli jest inna strona (np. hostująca iframe), możemy też spróbować wstrzyknąć do wszystkich frame'ów,
  // co zadziała tylko w frame'ach, gdzie mamy host_permissions.
  if (isYouTubeWatchOrEmbed) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ['popup_injector.js'],
      world: 'MAIN'
    }).catch(err => console.error('inject error:', err));
  } else {
    // Opcjonalnie: spróbuj wstrzyknąć do wszystkich frame'ów — nie zaszkodzi, 
    // ale w frame'ach bez uprawnień wstrzyknięcie zostanie zignorowane.
    chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ['popup_injector.js'],
      world: 'MAIN'
    }).catch(err => console.error('inject error (non-youtube):', err));
  }
});
