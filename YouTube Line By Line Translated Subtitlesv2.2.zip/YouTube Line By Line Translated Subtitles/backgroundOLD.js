chrome.action.onClicked.addListener((tab) => {
  if (tab.url && (tab.url.includes("youtube.com/watch") || tab.url.includes("youtube-nocookie.com/watch"))) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['popup_injector.js'],
      world: 'MAIN'
    });
  }
});